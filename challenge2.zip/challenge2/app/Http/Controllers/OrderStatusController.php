<?php

namespace App\Http\Controllers;

use App\Models\OrderStatus;
use Illuminate\Http\Request;

class OrderStatusController extends Controller
{
    public function index()
    {
        $orderStatuses = OrderStatus::all();
        return view('order_statuses.index', compact('orderStatuses'));
    }

    // Implement other CRUD methods such as store, edit, update, destroy as needed
}
