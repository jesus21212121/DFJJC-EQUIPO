<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
    use HasFactory;

    protected $fillable = ['username', 'password', 'role', 'active'];

    // Define setter methods
    public function setUsername($username)
    {
        $this->username = $username;
    }

    public function setPassword($password)
    {
        $this->password = bcrypt($password); // Hash the password
    }

    public function setRole($role)
    {
        $this->role = $role;
    }
}

